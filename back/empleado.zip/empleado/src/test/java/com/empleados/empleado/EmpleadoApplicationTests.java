package com.empleados.empleado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpleadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
